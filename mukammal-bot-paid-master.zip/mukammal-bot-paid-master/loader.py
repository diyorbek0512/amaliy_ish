from aiogram import Bot, Dispatcher, types
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from aiogram.dispatcher.filters.state import State, StatesGroup
from aiogram.dispatcher import FSMContext
from aiogram.utils.executor import start_polling
from data import config

bot = Bot(token=config.BOT_TOKEN, parse_mode=types.ParseMode.HTML)
storage = MemoryStorage()
dp = Dispatcher(bot, storage=storage)

class Form(StatesGroup):
    name = State()
    phone_number = State()
    suggestions = State()
    media = State()
    ready_for_next = State()

@dp.message_handler(commands=['next'], state='*')
async def command_next(message: types.Message, state: FSMContext):
        async with state.proxy() as data:
            if 'name' in data and 'phone_number' in data:
                # If name and phone number are already stored, go to suggestions
                await Form.suggestions.set()
                await message.reply("Sizda qandaydir taklif yoki shikoyatlar bormi?")
            else:
                # If name and phone number are not stored, start from the beginning
                await Form.name.set()
                await message.reply("Assalomu alaykum, iltimos, ism familiyangizni kiriting")


@dp.message_handler(commands=['start'])
async def cmd_start(message: types.Message):
    await Form.name.set()
    await message.reply(f"Assalomu alaykum, iltimos, ism familiyangizni kiriting")


@dp.message_handler(state=Form.name)
async def process_name(message: types.Message, state: FSMContext):
    async with state.proxy() as data:
        data['name'] = message.text
    await Form.next()
    await message.reply(f"Rahmat, {message.text}. Endigi navbatda murojaat uchun telefon raqamingizni qoldiring: ")


@dp.message_handler(state=Form.phone_number)
async def process_phone_number(message: types.Message, state: FSMContext):
    async with state.proxy() as data:
        data['phone_number'] = message.text
    await Form.next()
    await message.reply("Sizda qandaydir taklif yoki shikoyatlar bormi?")

@dp.message_handler(state=Form.suggestions)
async def process_suggestions(message: types.Message, state: FSMContext):
    async with state.proxy() as data:
        data['suggestions'] = message.text
    await Form.media.set()
    await message.reply(
        "Endi bizga media faylni yuboring,\nyoki shunchaki /skip tugmasi orqali bu qadamni o'tkazib yuboring")


@dp.message_handler(state=Form.media, commands=['skip'])
async def skip_media(message: types.Message, state: FSMContext):
    async with state.proxy() as data:
        caption = f"ISM: {data['name']}\nTEL: {data['phone_number']}\nTAKLIFLAR: {data['suggestions']}"
        for admin_id in config.ADMINS:
            await bot.send_message(admin_id, caption)

    await Form.ready_for_next.set()
    await message.reply("Media fayl yuborish o'tkazib yuborildi. Yana takliflaringiz bo'lsa, /next tugmasini bosing.")

@dp.message_handler(content_types=['photo', 'video'], state=Form.media)
async def process_media(message: types.Message, state: FSMContext):
    async def process_media(message: types.Message, state: FSMContext):
        async with state.proxy() as data:
            caption = f"ISM: {data['name']}\nTEL: {data['phone_number']}\nTAKLIFLAR: {data['suggestions']}"

        for admin_id in config.ADMINS:
            if message.photo:
                await bot.send_photo(admin_id, message.photo[-1].file_id, caption=caption)
            elif message.video:
                await bot.send_video(admin_id, message.video.file_id, caption=caption)

        await Form.ready_for_next.set()
        await message.reply(
            "Media faylingiz va munosabatingiz uchun rahmat! Yana takliflaringiz bo'lsa, /next tugmasini bosing.")


if __name__ == '__main__':
    start_polling(dp, skip_updates=True)










